-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Aug 30, 2025 at 06:25 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phonestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `username` varchar(100) NOT NULL,
  `phone_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`username`, `phone_id`, `quantity`, `cart_id`) VALUES
('davai112', 6, 2, 12),
('davai112', 1, 1, 13);

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE `phone` (
  `phone_id` int(11) NOT NULL,
  `phone_name` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `storage` int(11) NOT NULL,
  `ram` int(11) NOT NULL,
  `battery` int(11) NOT NULL,
  `os` varchar(100) NOT NULL,
  `link_gambar` text NOT NULL,
  `descP` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`phone_id`, `phone_name`, `brand`, `price`, `storage`, `ram`, `battery`, `os`, `link_gambar`, `descP`) VALUES
(1, 'iPhone 15 Pro', 'Apple', 999, 256, 8, 3274, 'iOS 17', 'https://512pixels.net/wp-content/uploads/2023/12/iphone-15-pro-max-natural.jpg', ''),
(2, 'Samsung Galaxy S23', 'Samsung', 899, 256, 8, 3900, 'Android 13', 'https://www.lowyat.net/wp-content/uploads/2023/04/Samsung-Galaxy-S23-Review-1.jpg', ''),
(3, 'Google Pixel 8', 'Google', 799, 128, 8, 4575, 'Android 14', 'https://static1.pocketnowimages.com/wordpress/wp-content/uploads/wm/2023/10/pixel-8-pro-official-in-house-2-1.jpeg', ''),
(4, 'OnePlus 11', 'OnePlus', 749, 256, 16, 5000, 'Android 13', 'https://www.zdnet.com/a/img/2023/02/07/1d011dca-a05d-4758-bb5a-cc1ea9cb94f6/oneplus-11-in-ahnd.jpg', ''),
(5, 'Xiaomi 13 Pro', 'Xiaomi', 699, 256, 12, 4820, 'Android 13', 'https://cdn.mos.cms.futurecdn.net/wmS7khgHzdpwrXRaTXSdVN.jpg', ''),
(6, 'Oppo Find X6 Pro', 'Oppo', 850, 512, 16, 5000, 'Android 13', 'https://amateurphotographer.com/wp-content/uploads/sites/7/2023/09/oppo_find_x6_pro_10.jpeg', ''),
(7, 'Asus ROG Phone 7', 'Asus', 1099, 512, 16, 6000, 'Android 13', 'https://nextrift.com/wp-content/uploads/2023/04/asus-rog-phone-7-unboxing-hands-on-5.jpg', ''),
(8, 'Realme GT Neo 5', 'Realme', 599, 256, 12, 5000, 'Android 13', 'https://i.ytimg.com/vi/delDa0UPAiY/maxresdefault.jpg', ''),
(9, 'Huawei P60 Pro', 'Huawei', 899, 256, 8, 4815, 'HarmonyOS 3', 'https://www.lowyat.net/wp-content/uploads/2023/05/Huawei-P60-Pro-750x563.jpg', ''),
(10, 'Sony Xperia 1 V', 'Sony', 1199, 256, 12, 5000, 'Android 13', 'https://www.lbtechreviews.com/wp-content/uploads/2023/06/Sony_Xperia1_V_TOP-1080x608.jpeg', ''),
(11, 'Google Pixel 7 Pro', 'Google', 899, 256, 12, 5000, 'Android 13', 'https://static1.anpoimages.com/wordpress/wp-content/uploads/wm/2024/08/img_5688.jpg', ''),
(12, 'Samsung Galaxy Z Flip 5', 'Samsung', 999, 256, 8, 3700, 'Android 13', 'https://gadgetren.com/wp-content/uploads/2023/09/Samsung-Galaxy-Z-Flip-Dual-Preview.jpg', ''),
(13, 'iPhone 14 Pro Max', 'Apple', 1199, 512, 6, 4323, 'iOS 16', 'https://eshop.macsales.com/blog/wp-content/uploads/2022/09/Apple-iPhone-14-Pro-iPhone-14-Pro-Max-hero-220907-scaled.jpg', ''),
(14, 'OnePlus Nord 3', 'OnePlus', 599, 256, 12, 5000, 'Android 13', 'https://www.techadvisor.com/wp-content/uploads/2023/10/P_20230629_170725-1.jpg', ''),
(15, 'Xiaomi Redmi Note 12 Pro+', 'Xiaomi', 429, 256, 8, 4980, 'Android 13', 'https://bm.soyacincau.com/wp-content/uploads/2023/04/230404-redmi-note-12-pro-plus-5g-hero.jpg', ''),
(16, 'Sony Xperia 5 V', 'Sony', 999, 256, 8, 5000, 'Android 13', 'https://www.notebookcheck.net/uploads/tx_nbc2/Sony_Xperia_5_V.JPG', ''),
(17, 'Asus Zenfone 10', 'Asus', 799, 256, 16, 4300, 'Android 13', 'https://static1.pocketlintimages.com/wordpress/wp-content/uploads/wm/162118-phones-review-asus-zenfone-9-review-image1-f4i9ighoa7.jpg', ''),
(18, 'Huawei Mate 60 Pro', 'Huawei', 1099, 512, 12, 5000, 'HarmonyOS 4', 'https://i.ytimg.com/vi/gG2d9UjVfAE/maxresdefault.jpg', ''),
(19, 'Realme 11 Pro+', 'Realme', 499, 256, 12, 5000, 'Android 13', 'https://www.vopmart.com/media/wysiwyg/Review/realme-11-pro-plus-review-01.jpg', ''),
(20, 'Nothing Phone (2)', 'Nothing', 699, 256, 12, 4700, 'Android 13', 'https://www.lowyat.net/wp-content/uploads/2023/07/Nothing-Phone-2-hands-on-007.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `phone_order`
--

CREATE TABLE `phone_order` (
  `id` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `phone_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` float NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phone_order`
--

INSERT INTO `phone_order` (`id`, `user_id`, `phone_id`, `quantity`, `total_price`, `status`) VALUES
(24, 'Kugisaki Nobara', 6, 7, 5950, 'Completed'),
(25, 'Kugisaki Nobara', 2, 3, 2697, 'Order Placed'),
(26, 'Kugisaki Nobara', 2, 1, 899, 'Order Placed'),
(27, 'Kugisaki Nobara', 2, 1, 899, 'Order Placed'),
(28, 'Kugisaki Nobara', 5, 3, 2097, 'Order Placed'),
(29, 'davai112', 3, 1, 799, 'Order Placed'),
(30, 'Kugisaki Nobara', 3, 5, 3995, 'Order Placed'),
(31, 'Kugisaki Nobara', 3, 3, 2397, 'Order Placed');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `email`) VALUES
('davai112', '1', 'sasasa@sasa.sas.com'),
('Kugisaki Nobara', '1', 'affan2088a@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
  ADD PRIMARY KEY (`phone_id`);

--
-- Indexes for table `phone_order`
--
ALTER TABLE `phone_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
  MODIFY `phone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `phone_order`
--
ALTER TABLE `phone_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
